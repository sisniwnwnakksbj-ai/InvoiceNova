import { useEffect, useRef } from "react";

/**
 * Adsterra 320x50 banner ad unit.
 * Injects the atOptions config + invoke.js script into a dedicated container
 * so it works correctly with client-side routing (no global script collisions).
 */
export function AdsterraBanner() {
  const containerRef = useRef<HTMLDivElement>(null);
  const injectedRef = useRef(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || injectedRef.current) return;
    injectedRef.current = true;

    const configScript = document.createElement("script");
    configScript.type = "text/javascript";
    configScript.text = `
      atOptions = {
        'key' : 'ed51958cae1df55802dd11b485467ba7',
        'format' : 'iframe',
        'height' : 50,
        'width' : 320,
        'params' : {}
      };
    `;
    el.appendChild(configScript);

    const invokeScript = document.createElement("script");
    invokeScript.type = "text/javascript";
    invokeScript.src =
      "//www.highperformanceformat.com/ed51958cae1df55802dd11b485467ba7/invoke.js";
    invokeScript.async = true;
    el.appendChild(invokeScript);
  }, []);

  return (
    <div className="w-full flex justify-center py-4 no-print">
      <div
        ref={containerRef}
        style={{ width: 320, height: 50 }}
        aria-label="Advertisement"
      />
    </div>
  );
}
