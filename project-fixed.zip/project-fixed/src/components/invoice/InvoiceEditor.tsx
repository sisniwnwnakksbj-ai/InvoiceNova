import { Link } from "@tanstack/react-router";
import { useCallback, useRef } from "react";
import type { Invoice, LineItem } from "@/lib/invoice/types";
import { CURRENCIES, TEMPLATES } from "@/lib/invoice/types";
import { isPremiumTemplate, unlockableTemplate } from "@/lib/premium";
import { Lock, Plus, Trash2, Upload, X } from "lucide-react";

interface Props {
  invoice: Invoice;
  onChange: (next: Invoice) => void;
}

export function InvoiceEditor({ invoice, onChange }: Props) {
  const set = useCallback(<K extends keyof Invoice>(key: K, value: Invoice[K]) => {
    onChange({ ...invoice, [key]: value });
  }, [invoice, onChange]);

  const setItem = (id: string, patch: Partial<LineItem>) => {
    onChange({
      ...invoice,
      items: invoice.items.map((i) => (i.id === id ? { ...i, ...patch } : i)),
    });
  };

  const addItem = () =>
    onChange({
      ...invoice,
      items: [
        ...invoice.items,
        { id: crypto.randomUUID(), description: "", quantity: 1, price: 0 },
      ],
    });

  const removeItem = (id: string) =>
    onChange({ ...invoice, items: invoice.items.filter((i) => i.id !== id) });

  const fileRef = useRef<HTMLInputElement>(null);
  const handleLogo = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => set("logo", String(reader.result));
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <Card title="Template" desc="Choose a style for your invoice">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {TEMPLATES.map((t) => {
            const active = invoice.template === t.id;
            const locked = isPremiumTemplate(t.id) && !unlockableTemplate(t.id);
            return (
              <Link
                key={t.id}
                to={locked ? "/premium" : "/app"}
                onClick={(e) => {
                  if (locked) return;
                  e.preventDefault();
                  set("template", t.id);
                }}
                className={
                  "text-left p-3 rounded-lg border transition-all " +
                  (active
                    ? "border-primary bg-primary/5 ring-2 ring-primary/30"
                    : locked
                      ? "border-warning/40 bg-warning/5 hover:border-warning/70 hover:bg-warning/10"
                      : "border-border hover:border-primary/40 hover:bg-accent/50")
                }
              >
                <div className="text-sm font-medium flex items-center gap-2">
                  {t.name}
                  {t.premium && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-gradient-brand text-brand-foreground">
                      PRO
                    </span>
                  )}
                  {locked && <Lock className="h-3.5 w-3.5 text-warning" />}
                </div>
                <div className="text-xs text-muted-foreground">
                  {locked ? "Upgrade to unlock this premium style" : t.tagline}
                </div>
              </Link>
            );
          })}
        </div>
      </Card>

      <Card title="Invoice details">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Invoice number">
            <Input value={invoice.number} onChange={(v) => set("number", v)} />
          </Field>
          <Field label="Currency">
            <Select value={invoice.currency} onChange={(v) => set("currency", v)}>
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.code} — {c.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Issue date">
            <Input type="date" value={invoice.issueDate} onChange={(v) => set("issueDate", v)} />
          </Field>
          <Field label="Due date">
            <Input type="date" value={invoice.dueDate} onChange={(v) => set("dueDate", v)} />
          </Field>
          <Field label="Status">
            <Select
              value={invoice.status}
              onChange={(v) => set("status", v as Invoice["status"])}
            >
              <option value="draft">Draft</option>
              <option value="sent">Sent</option>
              <option value="paid">Paid</option>
            </Select>
          </Field>
          <Field label="Company logo">
            <div className="flex items-center gap-2">
              {invoice.logo ? (
                <div className="relative">
                  <img src={invoice.logo} alt="logo" className="h-9 w-9 rounded object-contain border border-border bg-card" />
                  <button
                    onClick={() => set("logo", undefined)}
                    className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full h-4 w-4 grid place-items-center"
                    aria-label="Remove logo"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ) : null}
              <button
                onClick={() => fileRef.current?.click()}
                className="flex items-center gap-2 text-sm px-3 h-9 rounded-lg border border-dashed border-border hover:border-primary/60 hover:bg-accent/50 transition"
              >
                <Upload className="h-4 w-4" /> Upload
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleLogo(e.target.files?.[0])}
              />
            </div>
          </Field>
        </div>
      </Card>

      <div className="grid sm:grid-cols-2 gap-6">
        <Card title="From">
          <PartyFields
            party={invoice.from}
            onChange={(p) => set("from", p)}
            prefix="Your"
          />
        </Card>
        <Card title="Bill to">
          <PartyFields party={invoice.to} onChange={(p) => set("to", p)} prefix="Client" />
        </Card>
      </div>

      <Card title="Line items" right={
        <button
          onClick={addItem}
          className="flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          <Plus className="h-4 w-4" /> Add item
        </button>
      }>
        <div className="space-y-2">
          {invoice.items.map((it) => (
            <div key={it.id} className="grid grid-cols-12 gap-2 items-center">
              <div className="col-span-12 sm:col-span-6">
                <Input
                  placeholder="Description"
                  value={it.description}
                  onChange={(v) => setItem(it.id, { description: v })}
                />
              </div>
              <div className="col-span-3 sm:col-span-2">
                <Input
                  type="number"
                  placeholder="Qty"
                  value={String(it.quantity)}
                  onChange={(v) => setItem(it.id, { quantity: Number(v) })}
                />
              </div>
              <div className="col-span-6 sm:col-span-3">
                <Input
                  type="number"
                  placeholder="Price"
                  value={String(it.price)}
                  onChange={(v) => setItem(it.id, { price: Number(v) })}
                />
              </div>
              <div className="col-span-3 sm:col-span-1 flex justify-end">
                <button
                  onClick={() => removeItem(it.id)}
                  className="h-9 w-9 grid place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition"
                  aria-label="Remove item"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Totals & adjustments">
        <div className="grid grid-cols-3 gap-3">
          <Field label="Tax %">
            <Input type="number" value={String(invoice.taxRate)} onChange={(v) => set("taxRate", Number(v))} />
          </Field>
          <Field label="Discount">
            <Input type="number" value={String(invoice.discount)} onChange={(v) => set("discount", Number(v))} />
          </Field>
          <Field label="Shipping">
            <Input type="number" value={String(invoice.shipping)} onChange={(v) => set("shipping", Number(v))} />
          </Field>
        </div>
      </Card>

      <Card title="Notes & terms">
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Notes">
            <Textarea value={invoice.notes} onChange={(v) => set("notes", v)} />
          </Field>
          <Field label="Terms & conditions">
            <Textarea value={invoice.terms} onChange={(v) => set("terms", v)} />
          </Field>
        </div>
      </Card>
    </div>
  );
}

function PartyFields({
  party, onChange, prefix,
}: { party: Invoice["from"]; onChange: (p: Invoice["from"]) => void; prefix: string }) {
  const set = (k: keyof Invoice["from"], v: string) => onChange({ ...party, [k]: v });
  return (
    <div className="space-y-3">
      <Field label={`${prefix} name`}><Input value={party.name} onChange={(v) => set("name", v)} /></Field>
      <Field label="Email"><Input type="email" value={party.email} onChange={(v) => set("email", v)} /></Field>
      <Field label="Phone"><Input value={party.phone} onChange={(v) => set("phone", v)} /></Field>
      <Field label="Address"><Textarea rows={3} value={party.address} onChange={(v) => set("address", v)} /></Field>
    </div>
  );
}

function Card({
  title, desc, right, children,
}: { title: string; desc?: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-border bg-card p-5 shadow-soft">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
          {desc ? <p className="text-xs text-muted-foreground mt-0.5">{desc}</p> : null}
        </div>
        {right}
      </div>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function Input({
  value, onChange, type = "text", placeholder,
}: { value: string; onChange: (v: string) => void; type?: string; placeholder?: string }) {
  return (
    <input
      type={type}
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className="w-full h-9 px-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring transition"
    />
  );
}

function Textarea({
  value, onChange, rows = 3,
}: { value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <textarea
      value={value}
      rows={rows}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring transition resize-y"
    />
  );
}

function Select({
  value, onChange, children,
}: { value: string; onChange: (v: string) => void; children: React.ReactNode }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full h-9 px-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 focus:border-ring transition"
    >
      {children}
    </select>
  );
}
