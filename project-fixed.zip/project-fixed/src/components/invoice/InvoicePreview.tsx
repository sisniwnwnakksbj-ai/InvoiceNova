import { forwardRef } from "react";
import type { Invoice } from "@/lib/invoice/types";
import { calcTotals, formatMoney, lineTotal } from "@/lib/invoice/calc";

interface Props {
  invoice: Invoice;
}

const themes: Record<
  Invoice["template"],
  {
    page: string;
    header: string;
    accent: string;
    label: string;
    table: string;
    totalBox: string;
    chip: string;
  }
> = {
  minimal: {
    page: "bg-white text-neutral-900",
    header: "border-b border-neutral-200 pb-6",
    accent: "text-neutral-900",
    label: "text-neutral-500 uppercase tracking-widest text-[10px]",
    table: "border-t border-b border-neutral-200",
    totalBox: "border-t border-neutral-300",
    chip: "bg-neutral-100 text-neutral-700",
  },
  corporate: {
    page: "bg-white text-slate-900",
    header: "bg-slate-900 text-white -mx-12 -mt-12 px-12 py-8 mb-8",
    accent: "text-blue-700",
    label: "text-slate-500 uppercase tracking-wider text-[10px] font-semibold",
    table: "border-t-2 border-slate-900",
    totalBox: "bg-slate-900 text-white",
    chip: "bg-blue-50 text-blue-700",
  },
  modern: {
    page: "bg-white text-slate-900",
    header:
      "relative overflow-hidden -mx-12 -mt-12 px-12 py-10 mb-8 text-white bg-gradient-to-br from-violet-600 via-indigo-600 to-blue-500",
    accent: "text-violet-700",
    label: "text-slate-500 uppercase tracking-wider text-[10px] font-semibold",
    table: "border-t border-slate-200",
    totalBox: "bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-100",
    chip: "bg-violet-100 text-violet-700",
  },
  dark: {
    page: "relative overflow-hidden bg-neutral-950 text-neutral-100 ring-1 ring-neutral-800",
    header:
      "relative -mx-12 -mt-12 px-12 py-10 mb-8 border-b border-emerald-400/30 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.28),transparent_34%),linear-gradient(135deg,#050505,#171717_55%,#020617)]",
    accent: "text-emerald-300",
    label: "text-emerald-200/60 uppercase tracking-widest text-[10px]",
    table: "border-t border-b border-emerald-400/20",
    totalBox: "bg-gradient-to-br from-emerald-400/15 to-neutral-900 border border-emerald-400/25 shadow-[0_18px_45px_-30px_rgba(16,185,129,0.9)]",
    chip: "bg-emerald-400/15 text-emerald-200 ring-1 ring-emerald-300/30",
  },
  luxury: {
    page: "relative overflow-hidden bg-[#10100f] text-[#f7ead2] ring-1 ring-[#d7b46a]/40",
    header:
      "relative -mx-12 -mt-12 px-12 py-10 mb-8 border-b border-[#d7b46a]/50 bg-[linear-gradient(135deg,#0c0b09,#231b12_58%,#6f5522)] after:absolute after:inset-x-12 after:bottom-0 after:h-px after:bg-gradient-to-r after:from-transparent after:via-[#f5d990] after:to-transparent",
    accent: "text-[#f5d990]",
    label: "text-[#d7b46a]/75 uppercase tracking-[0.26em] text-[10px]",
    table: "border-t border-b border-[#d7b46a]/35",
    totalBox: "bg-[#f7ead2] text-[#17120b] border border-[#d7b46a] shadow-[0_22px_55px_-32px_rgba(215,180,106,0.95)]",
    chip: "bg-[#f5d990]/15 text-[#f5d990] ring-1 ring-[#d7b46a]/50",
  },
  creative: {
    page: "relative overflow-hidden bg-[#fff8fb] text-zinc-950 ring-1 ring-pink-200",
    header:
      "relative -mx-12 -mt-12 px-12 py-10 mb-8 text-white bg-[linear-gradient(135deg,#6d28d9,#db2777_50%,#fb923c)] before:absolute before:right-10 before:top-8 before:h-24 before:w-24 before:rounded-full before:border before:border-white/30 before:content-[''] after:absolute after:right-24 after:bottom-6 after:h-14 after:w-14 after:rounded-full after:bg-white/15 after:content-['']",
    accent: "text-fuchsia-700",
    label: "text-fuchsia-700/70 uppercase tracking-wider text-[10px] font-bold",
    table: "border-t-2 border-fuchsia-200",
    totalBox: "bg-gradient-to-br from-zinc-950 to-fuchsia-950 text-white shadow-[0_20px_50px_-30px_rgba(219,39,119,0.95)]",
    chip: "bg-white/20 text-white ring-1 ring-white/35",
  },
};

export const InvoicePreview = forwardRef<HTMLDivElement, Props>(function InvoicePreview(
  { invoice },
  ref,
) {
  const t = themes[invoice.template];
  const totals = calcTotals(invoice);
  const cur = invoice.currency;

  return (
    <div
      ref={ref}
      className={`mx-auto w-full ${t.page} p-12 shadow-soft`}
      style={{ aspectRatio: "1 / 1.414", maxWidth: 820 }}
    >
      <div className={t.header}>
        <div className="flex items-start justify-between gap-6">
          <div className="flex items-center gap-4">
            {invoice.logo ? (
              <img
                src={invoice.logo}
                alt="Logo"
                className="h-14 w-14 object-contain rounded-md bg-white/80 p-1"
              />
            ) : (
              <div className="h-14 w-14 rounded-md bg-white/15 grid place-items-center text-xs opacity-70">
                LOGO
              </div>
            )}
            <div>
              <div className="text-xs opacity-70">From</div>
              <div className="font-semibold text-base">{invoice.from.name || "Your Company"}</div>
              <div className="text-xs opacity-80 whitespace-pre-line">{invoice.from.address}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold tracking-tight">INVOICE</div>
            <div className="text-xs opacity-80 mt-1">{invoice.number}</div>
            <span className={`inline-block mt-2 px-2 py-0.5 rounded-full text-[10px] font-medium ${t.chip}`}>
              {invoice.status.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <div className={t.label}>Billed to</div>
          <div className="mt-2 font-semibold">{invoice.to.name || "Client name"}</div>
          <div className="text-sm opacity-80 whitespace-pre-line">{invoice.to.address}</div>
          {invoice.to.email && <div className="text-sm opacity-80">{invoice.to.email}</div>}
        </div>
        <div className="text-right space-y-2">
          <div>
            <div className={t.label}>Issue date</div>
            <div className="text-sm">{invoice.issueDate}</div>
          </div>
          <div>
            <div className={t.label}>Due date</div>
            <div className={`text-sm font-semibold ${t.accent}`}>{invoice.dueDate}</div>
          </div>
        </div>
      </div>

      <table className={`w-full text-sm ${t.table}`}>
        <thead>
          <tr className="text-left">
            <th className={`py-3 ${t.label}`}>Description</th>
            <th className={`py-3 text-right ${t.label}`}>Qty</th>
            <th className={`py-3 text-right ${t.label}`}>Price</th>
            <th className={`py-3 text-right ${t.label}`}>Amount</th>
          </tr>
        </thead>
        <tbody>
          {invoice.items.map((it) => (
            <tr key={it.id} className="border-t border-current/10 align-top">
              <td className="py-3 pr-4">{it.description || "—"}</td>
              <td className="py-3 text-right">{it.quantity}</td>
              <td className="py-3 text-right">{formatMoney(it.price, cur)}</td>
              <td className="py-3 text-right font-medium">{formatMoney(lineTotal(it), cur)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-8 flex justify-end">
        <div className={`w-full max-w-sm rounded-lg p-5 ${t.totalBox}`}>
          <Row label="Subtotal" value={formatMoney(totals.subtotal, cur)} />
          {totals.discount > 0 && (
            <Row label="Discount" value={`- ${formatMoney(totals.discount, cur)}`} />
          )}
          {invoice.taxRate > 0 && (
            <Row label={`Tax (${invoice.taxRate}%)`} value={formatMoney(totals.tax, cur)} />
          )}
          {totals.shipping > 0 && <Row label="Shipping" value={formatMoney(totals.shipping, cur)} />}
          <div className="border-t border-current/20 mt-3 pt-3 flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider opacity-80">Total due</span>
            <span className="text-xl font-bold">{formatMoney(totals.total, cur)}</span>
          </div>
        </div>
      </div>

      <div className="mt-10 grid grid-cols-2 gap-8 text-xs">
        {invoice.notes && (
          <div>
            <div className={t.label}>Notes</div>
            <p className="mt-1 opacity-80 whitespace-pre-line">{invoice.notes}</p>
          </div>
        )}
        {invoice.terms && (
          <div>
            <div className={t.label}>Terms</div>
            <p className="mt-1 opacity-80 whitespace-pre-line">{invoice.terms}</p>
          </div>
        )}
      </div>
    </div>
  );
});

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm py-1">
      <span className="opacity-75">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
