import { Link, useRouterState } from "@tanstack/react-router";
import { Crown, FileText, LayoutDashboard, Moon, Sun, Sparkles } from "lucide-react";
import { useTheme } from "@/lib/theme";

export function SiteHeader() {
  const { theme, toggle } = useTheme();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const link = (to: string, label: string, Icon?: typeof FileText) => {
    const active = path === to || (to !== "/" && path.startsWith(to));
    return (
      <Link
        to={to}
        className={
          "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors " +
          (active
            ? "bg-accent text-accent-foreground"
            : "text-muted-foreground hover:text-foreground hover:bg-accent/60")
        }
      >
        {Icon ? <Icon className="h-4 w-4" /> : null}
        {label}
      </Link>
    );
  };

  return (
    <header className="no-print sticky top-0 z-40 glass">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="h-8 w-8 rounded-xl bg-gradient-brand grid place-items-center shadow-elegant group-hover:shadow-glow transition-shadow">
            <FileText className="h-4 w-4 text-brand-foreground" />
          </div>
          <span className="font-semibold tracking-tight text-lg">
            Invoice<span className="text-gradient-brand">Flow</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {link("/app", "Editor", FileText)}
          {link("/dashboard", "Dashboard", LayoutDashboard)}
          {link("/templates", "Templates", Sparkles)}
          {link("/premium", "Premium", Crown)}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/premium"
            className="hidden md:inline-flex items-center gap-1.5 px-3 h-9 rounded-lg border border-warning/40 text-warning hover:bg-warning/10 text-sm font-medium transition"
          >
            <Crown className="h-4 w-4" /> Buy Premium
          </Link>
          <button
            onClick={toggle}
            aria-label="Toggle theme"
            className="h-9 w-9 grid place-items-center rounded-lg border border-border hover:bg-accent transition-colors"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <Link
            to="/app"
            className="hidden sm:inline-flex items-center px-4 h-9 rounded-lg bg-gradient-brand text-brand-foreground text-sm font-medium shadow-elegant hover:shadow-glow transition-all hover:-translate-y-0.5"
          >
            New invoice
          </Link>
        </div>
      </div>
    </header>
  );
}
