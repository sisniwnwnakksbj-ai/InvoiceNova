import { createFileRoute } from "@tanstack/react-router";

// CashMaal IPN (Instant Payment Notification) receiver.
// CashMaal POSTs payment status here. We log it so it can be reviewed
// in server logs. In production, persist to a DB and verify the payment
// by calling CashMaal's status API with your secret key.
export const Route = createFileRoute("/api/public/cashmaal-ipn")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const contentType = request.headers.get("content-type") ?? "";
          let payload: Record<string, unknown> = {};

          if (contentType.includes("application/json")) {
            payload = await request.json();
          } else {
            const form = await request.formData();
            payload = Object.fromEntries(form.entries());
          }

          console.log("[CashMaal IPN]", JSON.stringify(payload));

          // TODO: verify payload.status === "success" and mark the order
          // (payload.order_id) as paid in your database.

          return new Response("OK", { status: 200 });
        } catch (err) {
          console.error("[CashMaal IPN] error", err);
          return new Response("Bad Request", { status: 400 });
        }
      },
      GET: async () => new Response("CashMaal IPN endpoint", { status: 200 }),
    },
  },
});
