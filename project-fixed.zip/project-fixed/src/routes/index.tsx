import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { AdsterraBanner } from "@/components/AdsterraBanner";
import { ArrowRight, Check, Download, FileText, LayoutDashboard, Palette, Shield, Zap } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "InvoiceFlow — Free professional invoice generator" },
      { name: "description", content: "Create, customize, and download beautiful PDF invoices in seconds. Multi-currency, multiple templates, dark mode, and live preview." },
      { property: "og:title", content: "InvoiceFlow — Free professional invoice generator" },
      { property: "og:description", content: "Beautiful PDF invoices in seconds. Multi-currency, premium templates, live preview." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <AdsterraBanner />


      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-mesh opacity-80 pointer-events-none" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-20 pb-24 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs font-medium text-muted-foreground mb-6">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Free • No sign-up • Auto-saves locally
          </div>
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight">
            Send invoices that <br className="hidden sm:block" />
            <span className="text-gradient-brand">look like a brand</span>.
          </h1>
          <p className="mt-6 max-w-xl mx-auto text-lg text-muted-foreground">
            InvoiceFlow is the fastest way to create stunning, branded invoices.
            Pick a template, fill in details, download the PDF. Done.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/app"
              className="group inline-flex items-center gap-2 px-6 h-12 rounded-xl bg-gradient-brand text-brand-foreground font-medium shadow-elegant hover:shadow-glow hover:-translate-y-0.5 transition-all"
            >
              Create your first invoice
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
            </Link>
            <Link
              to="/templates"
              className="inline-flex items-center gap-2 px-6 h-12 rounded-xl glass font-medium hover:bg-accent/60 transition"
            >
              Browse templates
            </Link>
          </div>

          <div className="mt-16 mx-auto max-w-5xl">
            <div className="relative rounded-2xl glass p-2 shadow-elegant">
              <div className="rounded-xl bg-card overflow-hidden border border-border">
                <div className="flex items-center gap-1.5 px-4 py-2 border-b border-border bg-muted/40">
                  <div className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
                  <div className="h-2.5 w-2.5 rounded-full bg-warning/70" />
                  <div className="h-2.5 w-2.5 rounded-full bg-success/70" />
                  <div className="ml-3 text-xs text-muted-foreground">invoiceflow.app/app</div>
                </div>
                <MockEditor />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Everything you need to bill</h2>
          <p className="mt-3 text-muted-foreground">Built for freelancers, agencies, and small businesses.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <Feature icon={Zap} title="Live preview" desc="Watch your invoice update in real time as you type." />
          <Feature icon={Palette} title="Premium templates" desc="Minimal, Corporate, Modern, Dark, Luxury, Creative." />
          <Feature icon={Download} title="Pixel-perfect PDF" desc="A4 export at 2× resolution, ready to print or email." />
          <Feature icon={FileText} title="Multi-currency" desc="12 currencies, tax, discount, shipping — automatic math." />
          <Feature icon={LayoutDashboard} title="Invoice history" desc="Every invoice is saved locally — search and reopen anytime." />
          <Feature icon={Shield} title="Private by default" desc="No accounts, no servers. Your data stays in your browser." />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-20">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-border bg-card p-8">
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Free forever</div>
            <div className="mt-2 text-4xl font-bold">$0</div>
            <p className="text-sm text-muted-foreground mt-1">For freelancers getting started.</p>
            <ul className="mt-6 space-y-2 text-sm">
              {["Unlimited invoices", "3 core templates", "PDF export", "Local history"].map((f) => (
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-success" />{f}</li>
              ))}
            </ul>
            <Link to="/app" className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline">
              Get started <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="rounded-2xl p-8 relative overflow-hidden text-brand-foreground bg-gradient-brand shadow-elegant">
            <div className="text-xs uppercase tracking-widest opacity-80">Pro</div>
            <div className="mt-2 text-4xl font-bold">$9<span className="text-base font-medium opacity-80">/mo</span></div>
            <p className="text-sm opacity-90 mt-1">For agencies and teams who care about brand.</p>
            <ul className="mt-6 space-y-2 text-sm">
              {["Everything in Free", "All premium templates", "Remove watermark", "Priority support"].map((f) => (
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4" />{f}</li>
              ))}
            </ul>
            <Link to="/premium" className="mt-6 inline-flex items-center gap-2 text-sm font-medium bg-white/15 hover:bg-white/25 transition px-4 h-9 rounded-lg backdrop-blur">
              Upgrade to Pro <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div>© {new Date().getFullYear()} InvoiceFlow. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <Link to="/app" className="hover:text-foreground">Editor</Link>
            <Link to="/dashboard" className="hover:text-foreground">Dashboard</Link>
            <Link to="/templates" className="hover:text-foreground">Templates</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Feature({ icon: Icon, title, desc }: { icon: typeof Zap; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 hover:shadow-elegant transition-shadow">
      <div className="h-10 w-10 rounded-xl bg-gradient-brand grid place-items-center text-brand-foreground shadow-elegant">
        <Icon className="h-5 w-5" />
      </div>
      <div className="mt-4 font-semibold">{title}</div>
      <p className="text-sm text-muted-foreground mt-1">{desc}</p>
    </div>
  );
}

function MockEditor() {
  return (
    <div className="grid grid-cols-5 min-h-[360px]">
      <div className="col-span-2 p-6 border-r border-border bg-muted/30 space-y-3">
        <div className="h-3 w-24 rounded bg-muted" />
        <div className="h-9 rounded-lg bg-card border border-border" />
        <div className="h-9 rounded-lg bg-card border border-border" />
        <div className="h-9 rounded-lg bg-card border border-border w-2/3" />
        <div className="h-px bg-border my-4" />
        <div className="h-3 w-20 rounded bg-muted" />
        <div className="h-16 rounded-lg bg-card border border-border" />
      </div>
      <div className="col-span-3 p-6 bg-gradient-to-br from-background to-muted/40">
        <div className="rounded-lg bg-white shadow-elegant p-6 text-slate-900 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-500">From</div>
              <div className="font-semibold">Acme Studio</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold">INVOICE</div>
              <div className="text-[10px] text-slate-500">INV-2026-0421</div>
            </div>
          </div>
          <div className="mt-4 border-t border-slate-200 pt-2 space-y-1">
            {[60, 72, 48].map((w, i) => (
              <div key={i} className="flex justify-between">
                <div className={`h-2 rounded bg-slate-200`} style={{ width: w }} />
                <div className="h-2 w-10 rounded bg-slate-200" />
              </div>
            ))}
          </div>
          <div className="mt-3 flex justify-end">
            <div className="rounded bg-violet-50 px-3 py-2 text-violet-700 font-semibold">$4,200.00</div>
          </div>
        </div>
      </div>
    </div>
  );
}
