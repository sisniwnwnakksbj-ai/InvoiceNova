import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { deleteInvoice, loadInvoices } from "@/lib/invoice/storage";
import type { Invoice } from "@/lib/invoice/types";
import { calcTotals, formatMoney } from "@/lib/invoice/calc";
import { FileText, Plus, Search, Trash2, TrendingUp, Users, Wallet } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — InvoiceFlow" },
      { name: "description", content: "View, search, and manage your invoices." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const [items, setItems] = useState<Invoice[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => { setItems(loadInvoices()); }, []);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return items;
    return items.filter((i) =>
      [i.number, i.to.name, i.from.name, i.status].some((v) => v?.toLowerCase().includes(s)),
    );
  }, [items, q]);

  const stats = useMemo(() => {
    const totals = items.map((i) => ({ ...calcTotals(i), inv: i }));
    const revenue = totals.filter((t) => t.inv.status === "paid").reduce((s, t) => s + t.total, 0);
    const outstanding = totals.filter((t) => t.inv.status !== "paid").reduce((s, t) => s + t.total, 0);
    const clients = new Set(items.map((i) => i.to.name).filter(Boolean)).size;
    return { revenue, outstanding, clients, count: items.length };
  }, [items]);

  const remove = (id: string) => {
    deleteInvoice(id);
    setItems(loadInvoices());
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">All your invoices, in one place.</p>
          </div>
          <Link
            to="/app"
            className="inline-flex items-center gap-1.5 h-10 px-4 rounded-lg bg-gradient-brand text-brand-foreground font-medium shadow-elegant hover:shadow-glow transition"
          >
            <Plus className="h-4 w-4" /> New invoice
          </Link>
        </div>

        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Stat icon={Wallet} label="Paid revenue" value={formatMoney(stats.revenue, "USD")} accent="text-success" />
          <Stat icon={TrendingUp} label="Outstanding" value={formatMoney(stats.outstanding, "USD")} accent="text-warning" />
          <Stat icon={FileText} label="Invoices" value={String(stats.count)} />
          <Stat icon={Users} label="Clients" value={String(stats.clients)} />
        </div>

        <div className="mt-8 rounded-2xl border border-border bg-card">
          <div className="p-4 flex items-center gap-3 border-b border-border">
            <div className="relative flex-1">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search by number, client, status…"
                className="w-full h-10 pl-9 pr-3 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring/40"
              />
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="p-16 text-center">
              <div className="mx-auto h-12 w-12 rounded-2xl bg-gradient-brand grid place-items-center text-brand-foreground shadow-elegant">
                <FileText className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-semibold">No invoices yet</h3>
              <p className="text-sm text-muted-foreground mt-1">Create your first invoice to see it here.</p>
              <Link to="/app" className="mt-4 inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-gradient-brand text-brand-foreground text-sm font-medium shadow-elegant">
                <Plus className="h-4 w-4" /> Create invoice
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
                    <th className="py-3 px-4">Number</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Issue</th>
                    <th className="py-3 px-4">Due</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Total</th>
                    <th className="py-3 px-4"></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((i) => {
                    const { total } = calcTotals(i);
                    return (
                      <tr key={i.id} className="border-b border-border last:border-0 hover:bg-accent/40 transition">
                        <td className="py-3 px-4 font-medium">
                          <Link to="/app" search={{ id: i.id }} className="hover:underline">
                            {i.number}
                          </Link>
                        </td>
                        <td className="py-3 px-4">{i.to.name || <span className="text-muted-foreground">—</span>}</td>
                        <td className="py-3 px-4 text-muted-foreground">{i.issueDate}</td>
                        <td className="py-3 px-4 text-muted-foreground">{i.dueDate}</td>
                        <td className="py-3 px-4"><StatusBadge status={i.status} /></td>
                        <td className="py-3 px-4 text-right font-medium">{formatMoney(total, i.currency)}</td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => remove(i.id)}
                            className="h-8 w-8 inline-grid place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition"
                            aria-label="Delete invoice"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, accent }: { icon: typeof Wallet; label: string; value: string; accent?: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <Icon className={`h-4 w-4 ${accent ?? "text-muted-foreground"}`} />
      </div>
      <div className="mt-2 text-2xl font-bold tracking-tight">{value}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: Invoice["status"] }) {
  const map: Record<Invoice["status"], string> = {
    draft: "bg-muted text-muted-foreground",
    sent: "bg-primary/10 text-primary",
    paid: "bg-success/15 text-success",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize ${map[status]}`}>
      {status}
    </span>
  );
}
