import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { InvoiceEditor } from "@/components/invoice/InvoiceEditor";
import { InvoicePreview } from "@/components/invoice/InvoicePreview";
import type { Invoice } from "@/lib/invoice/types";
import { blankInvoice } from "@/lib/invoice/calc";
import { loadDraft, saveDraft, upsertInvoice, getInvoice } from "@/lib/invoice/storage";
import { exportElementToPdf } from "@/lib/invoice/pdf";
import { isPremiumActive, isPremiumTemplate } from "@/lib/premium";
import { Copy, Download, Loader2, Printer, Save } from "lucide-react";

export const Route = createFileRoute("/app")({
  validateSearch: (s: Record<string, unknown>) => ({ id: typeof s.id === "string" ? s.id : undefined }),
  head: () => ({
    meta: [
      { title: "Invoice editor — InvoiceFlow" },
      { name: "description", content: "Build a professional invoice with a live preview. Export to PDF in one click." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: EditorPage,
});

function EditorPage() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const previewRef = useRef<HTMLDivElement>(null);

  // hydrate (client-only to avoid SSR mismatch from Date.now/Math.random)
  useEffect(() => {
    if (id) {
      const found = getInvoice(id);
      if (found) {
        setInvoice(isPremiumTemplate(found.template) && !isPremiumActive() ? { ...found, template: "modern" } : found);
        setHydrated(true);
        return;
      }
    }
    const draft = loadDraft();
    const initial = draft ?? blankInvoice();
    setInvoice(isPremiumTemplate(initial.template) && !isPremiumActive() ? { ...initial, template: "modern" } : initial);
    setHydrated(true);
  }, [id]);

  // autosave draft
  useEffect(() => {
    if (!hydrated || !invoice) return;
    const t = setTimeout(() => {
      saveDraft(invoice);
      setSavedAt(Date.now());
    }, 400);
    return () => clearTimeout(t);
  }, [invoice, hydrated]);

  const [saveLabel, setSaveLabel] = useState("Auto-saving");
  useEffect(() => {
    if (!savedAt) { setSaveLabel("Auto-saving"); return; }
    const update = () => {
      const s = Math.floor((Date.now() - savedAt) / 1000);
      setSaveLabel(s < 3 ? "Saved" : "Saved · just now");
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, [savedAt]);

  const handleDownload = useCallback(async () => {
    if (!previewRef.current || !invoice) return;
    setExporting(true);
    try {
      await exportElementToPdf(previewRef.current, `${invoice.number || "invoice"}.pdf`);
    } finally {
      setExporting(false);
    }
  }, [invoice]);

  const handleSave = useCallback(() => {
    if (!invoice) return;
    const saved = upsertInvoice(invoice);
    setInvoice(saved);
    navigate({ to: "/dashboard" });
  }, [invoice, navigate]);

  const handleDuplicate = useCallback(() => {
    if (!invoice) return;
    const next: Invoice = {
      ...invoice,
      id: crypto.randomUUID(),
      number: invoice.number.replace(/(\d+)(?!.*\d)/, (m) => String(Number(m) + 1)),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setInvoice(next);
  }, [invoice]);

  // shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
        e.preventDefault(); handleSave();
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "p") {
        e.preventDefault(); window.print();
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d") {
        e.preventDefault(); handleDownload();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [handleSave, handleDownload]);

  if (!invoice) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-20 text-center text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin inline-block mr-2" /> Loading editor…
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <div className="no-print sticky top-16 z-30 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            <span className="font-semibold">{invoice.number}</span>
            <span className="text-muted-foreground hidden sm:inline">· {saveLabel}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleDuplicate} className="hidden sm:inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-sm border border-border hover:bg-accent transition">
              <Copy className="h-4 w-4" /> Duplicate
            </button>
            <button onClick={() => window.print()} className="hidden sm:inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-sm border border-border hover:bg-accent transition">
              <Printer className="h-4 w-4" /> Print
            </button>
            <button onClick={handleSave} className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-sm border border-border hover:bg-accent transition">
              <Save className="h-4 w-4" /> Save
            </button>
            <button
              onClick={handleDownload}
              disabled={exporting}
              className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg text-sm font-medium bg-gradient-brand text-brand-foreground shadow-elegant hover:shadow-glow transition disabled:opacity-60"
            >
              {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              {exporting ? "Building PDF" : "Download PDF"}
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6 grid lg:grid-cols-2 gap-6">
        <div className="min-w-0">
          <InvoiceEditor invoice={invoice} onChange={setInvoice} />
        </div>
        <div className="min-w-0">
          <div className="lg:sticky lg:top-32">
            <div className="rounded-2xl bg-muted/40 p-4 border border-border overflow-auto max-h-[calc(100vh-180px)]">
              <InvoicePreview ref={previewRef} invoice={invoice} />
            </div>
            <div className="mt-3 text-xs text-muted-foreground text-center">
              Tip: <kbd className="px-1.5 py-0.5 rounded border border-border bg-card">⌘D</kbd> download ·{" "}
              <kbd className="px-1.5 py-0.5 rounded border border-border bg-card">⌘S</kbd> save ·{" "}
              <kbd className="px-1.5 py-0.5 rounded border border-border bg-card">⌘P</kbd> print
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
