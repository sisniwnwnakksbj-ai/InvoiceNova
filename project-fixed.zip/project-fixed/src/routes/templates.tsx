import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { InvoicePreview } from "@/components/invoice/InvoicePreview";
import { blankInvoice } from "@/lib/invoice/calc";
import { TEMPLATES, type TemplateId } from "@/lib/invoice/types";
import { ArrowRight } from "lucide-react";

export const Route = createFileRoute("/templates")({
  head: () => ({
    meta: [
      { title: "Invoice templates — InvoiceFlow" },
      { name: "description", content: "Pick from minimal, corporate, modern gradient, dark, luxury, and creative invoice templates." },
      { property: "og:title", content: "Invoice templates — InvoiceFlow" },
      { property: "og:description", content: "Six premium invoice templates ready to customize." },
      { property: "og:url", content: "/templates" },
    ],
    links: [{ rel: "canonical", href: "/templates" }],
  }),
  component: TemplatesPage,
});

function sample(id: TemplateId) {
  const inv = blankInvoice();
  inv.template = id;
  inv.from = { name: "Acme Studio", email: "hello@acme.co", phone: "+1 555 0100", address: "221B Baker St\nLondon, UK" };
  inv.to = { name: "Globex Corp.", email: "ap@globex.com", phone: "", address: "500 Market St\nSan Francisco, CA" };
  inv.items = [
    { id: "1", description: "Brand identity system", quantity: 1, price: 4200 },
    { id: "2", description: "Landing page design", quantity: 1, price: 2800 },
    { id: "3", description: "Revision rounds", quantity: 2, price: 350 },
  ];
  inv.taxRate = 8;
  return inv;
}

function TemplatesPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="max-w-2xl">
          <h1 className="text-4xl font-bold tracking-tight">Templates</h1>
          <p className="mt-2 text-muted-foreground">Pick a style. You can switch templates anytime — your data stays.</p>
        </div>

        <div className="mt-10 grid lg:grid-cols-2 gap-8">
          {TEMPLATES.map((t) => (
            <div key={t.id} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{t.name}</h3>
                    {t.premium && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-gradient-brand text-brand-foreground">PRO</span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{t.tagline}</p>
                </div>
                <Link
                  to={t.premium ? "/premium" : "/app"}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                >
                  {t.premium ? "Upgrade to use" : "Use template"} <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="rounded-xl bg-muted/40 p-3 overflow-hidden">
                <div style={{ transform: "scale(0.55)", transformOrigin: "top left", width: "182%" }}>
                  <InvoicePreview invoice={sample(t.id)} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
