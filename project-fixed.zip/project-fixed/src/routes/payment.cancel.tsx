import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { XCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/payment/cancel")({
  head: () => ({
    meta: [{ title: "Payment Cancelled — InvoiceFlow" }],
  }),
  component: CancelPage,
});

function CancelPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="mx-auto max-w-xl px-4 sm:px-6 pt-24 pb-20 text-center">
        <div className="mx-auto h-16 w-16 rounded-full bg-destructive/15 grid place-items-center">
          <XCircle className="h-9 w-9 text-destructive" />
        </div>
        <h1 className="mt-6 text-3xl sm:text-4xl font-bold tracking-tight">Payment cancelled</h1>
        <p className="mt-3 text-muted-foreground">
          Your payment was not completed. No charges were made. You can try again anytime.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Link
            to="/premium"
            className="inline-flex items-center gap-2 px-6 h-12 rounded-xl bg-gradient-brand text-brand-foreground font-medium shadow-elegant hover:shadow-glow transition"
          >
            Try again <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-6 h-12 rounded-xl glass font-medium hover:bg-accent/60 transition"
          >
            Back home
          </Link>
        </div>
      </section>
    </div>
  );
}
