import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { activatePremium } from "@/lib/premium";
import { CheckCircle2, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/payment/success")({
  head: () => ({
    meta: [{ title: "Payment Successful — InvoiceFlow" }],
  }),
  component: SuccessPage,
});

function SuccessPage() {
  const params = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
  const orderId = params?.get("order_id") ?? params?.get("trx_id") ?? "";

  useEffect(() => {
    activatePremium();
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="mx-auto max-w-xl px-4 sm:px-6 pt-24 pb-20 text-center">
        <div className="mx-auto h-16 w-16 rounded-full bg-success/15 grid place-items-center">
          <CheckCircle2 className="h-9 w-9 text-success" />
        </div>
        <h1 className="mt-6 text-3xl sm:text-4xl font-bold tracking-tight">Payment successful</h1>
        <p className="mt-3 text-muted-foreground">
          Thank you! Your InvoiceFlow Premium is now active.
          {orderId && (
            <>
              <br />
              Order reference: <span className="font-mono text-foreground">{orderId}</span>
            </>
          )}
        </p>
        <Link
          to="/app"
          className="mt-8 inline-flex items-center gap-2 px-6 h-12 rounded-xl bg-gradient-brand text-brand-foreground font-medium shadow-elegant hover:shadow-glow transition"
        >
          Open editor <ArrowRight className="h-4 w-4" />
        </Link>
      </section>
    </div>
  );
}
