import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { Check, Crown, Loader2, Shield } from "lucide-react";

export const Route = createFileRoute("/premium")({
  head: () => ({
    meta: [
      { title: "Go Premium — InvoiceFlow" },
      {
        name: "description",
        content:
          "Upgrade to InvoiceFlow Premium. Pay securely with Easypaisa, JazzCash, debit or credit card via CashMaal.",
      },
    ],
  }),
  component: PremiumPage,
});

const CASHMAAL_ENDPOINT = "https://cmaal.com/Pay/";
const CASHMAAL_WEB_ID = "11335";
const PREMIUM_PRICE_USD = "9";

function PremiumPage() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [origin, setOrigin] = useState("");
  const [orderId, setOrderId] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
    setOrderId(`INV-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  }, []);

  const handleBuy = (e: React.FormEvent<HTMLFormElement>) => {
    if (!email || !name || !origin) {
      e.preventDefault();
      return;
    }
    setLoading(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-mesh opacity-80 pointer-events-none" />
        <div className="relative mx-auto max-w-3xl px-4 sm:px-6 pt-16 pb-20">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs font-medium text-muted-foreground mb-5">
              <Crown className="h-3.5 w-3.5 text-warning" /> Premium plan
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">
              Unlock <span className="text-gradient-brand">InvoiceFlow Premium</span>
            </h1>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              One simple price. All premium templates, branding control, and priority support.
            </p>
          </div>

          <div className="mt-10 grid md:grid-cols-2 gap-6">
            <div className="rounded-2xl border border-border bg-card p-8">
              <div className="text-xs uppercase tracking-widest text-muted-foreground">
                Premium
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-5xl font-bold">${PREMIUM_PRICE_USD}</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <ul className="mt-6 space-y-2.5 text-sm">
                {[
                  "All premium templates",
                  "Remove watermark",
                  "Custom brand colors & logo",
                  "Unlimited PDF exports",
                  "Priority email support",
                ].map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-success" />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
                <Shield className="h-3.5 w-3.5" />
                Secure checkout via CashMaal
              </div>
            </div>

            <form
              method="POST"
              action={CASHMAAL_ENDPOINT}
              onSubmit={handleBuy}
              className="rounded-2xl p-8 bg-gradient-brand text-brand-foreground shadow-elegant"
            >
              <div className="text-xs uppercase tracking-widest opacity-80">Checkout</div>
              <div className="mt-2 text-2xl font-semibold">Buy Premium</div>
              <p className="text-sm opacity-90 mt-1">
                Pay with Easypaisa, JazzCash, debit or credit card.
              </p>

              <div className="mt-6 space-y-3">
                <div>
                  <label className="block text-xs font-medium opacity-90 mb-1">Full name</label>
                  <input
                    required
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    name="c_name"
                    className="w-full h-11 px-3 rounded-lg bg-white/15 placeholder-white/60 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/40 backdrop-blur"
                    placeholder="Jane Doe"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium opacity-90 mb-1">Email</label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    name="client_email"
                    className="w-full h-11 px-3 rounded-lg bg-white/15 placeholder-white/60 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/40 backdrop-blur"
                    placeholder="you@email.com"
                  />
                </div>
              </div>

              {/* CashMaal required hidden fields (per https://cashmaal.com/api) */}
              <input type="hidden" name="web_id" value={CASHMAAL_WEB_ID} />
              <input type="hidden" name="amount" value={PREMIUM_PRICE_USD} />
              <input type="hidden" name="currency" value="USD" />
              <input type="hidden" name="order_id" value={orderId} />
              <input type="hidden" name="pay_method" value="" />
              <input type="hidden" name="addi_info" value={`InvoiceFlow Premium - ${name}`} />
              <input type="hidden" name="success_url" value={`${origin}/payment/success`} />
              <input type="hidden" name="cancel_url" value={`${origin}/payment/cancel`} />

              <button
                type="submit"
                disabled={loading || !origin}
                className="mt-6 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-white text-foreground font-semibold hover:bg-white/90 transition disabled:opacity-70"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Redirecting to CashMaal…
                  </>
                ) : (
                  <>Pay ${PREMIUM_PRICE_USD} securely</>
                )}
              </button>

              <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px] opacity-90">
                <span className="px-2 py-1 rounded bg-white/15">Easypaisa</span>
                <span className="px-2 py-1 rounded bg-white/15">JazzCash</span>
                <span className="px-2 py-1 rounded bg-white/15">Debit Card</span>
                <span className="px-2 py-1 rounded bg-white/15">Credit Card</span>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
