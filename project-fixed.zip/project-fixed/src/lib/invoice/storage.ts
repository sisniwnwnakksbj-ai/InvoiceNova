import type { Invoice } from "./types";

const LIST_KEY = "invoiceflow.invoices.v1";
const DRAFT_KEY = "invoiceflow.draft.v1";

function safeLs(): Storage | null {
  if (typeof window === "undefined") return null;
  try { return window.localStorage; } catch { return null; }
}

export function loadInvoices(): Invoice[] {
  const ls = safeLs(); if (!ls) return [];
  try {
    const raw = ls.getItem(LIST_KEY);
    return raw ? (JSON.parse(raw) as Invoice[]) : [];
  } catch { return []; }
}

export function saveInvoices(list: Invoice[]) {
  const ls = safeLs(); if (!ls) return;
  ls.setItem(LIST_KEY, JSON.stringify(list));
}

export function upsertInvoice(inv: Invoice) {
  const list = loadInvoices();
  const idx = list.findIndex((i) => i.id === inv.id);
  const updated = { ...inv, updatedAt: Date.now() };
  if (idx >= 0) list[idx] = updated; else list.unshift(updated);
  saveInvoices(list);
  return updated;
}

export function deleteInvoice(id: string) {
  saveInvoices(loadInvoices().filter((i) => i.id !== id));
}

export function getInvoice(id: string): Invoice | undefined {
  return loadInvoices().find((i) => i.id === id);
}

export function saveDraft(inv: Invoice) {
  const ls = safeLs(); if (!ls) return;
  ls.setItem(DRAFT_KEY, JSON.stringify(inv));
}

export function loadDraft(): Invoice | null {
  const ls = safeLs(); if (!ls) return null;
  try {
    const raw = ls.getItem(DRAFT_KEY);
    return raw ? (JSON.parse(raw) as Invoice) : null;
  } catch { return null; }
}

export function clearDraft() {
  const ls = safeLs(); if (!ls) return;
  ls.removeItem(DRAFT_KEY);
}
