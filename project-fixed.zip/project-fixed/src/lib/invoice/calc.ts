import type { Invoice, LineItem } from "./types";
import { CURRENCIES } from "./types";

export function lineTotal(item: LineItem) {
  return (Number(item.quantity) || 0) * (Number(item.price) || 0);
}

export function calcTotals(invoice: Invoice) {
  const subtotal = invoice.items.reduce((s, i) => s + lineTotal(i), 0);
  const discount = Number(invoice.discount) || 0;
  const taxable = Math.max(0, subtotal - discount);
  const tax = taxable * ((Number(invoice.taxRate) || 0) / 100);
  const shipping = Number(invoice.shipping) || 0;
  const total = taxable + tax + shipping;
  return { subtotal, discount, tax, shipping, total };
}

export function formatMoney(amount: number, currency: string) {
  const cur = CURRENCIES.find((c) => c.code === currency);
  const symbol = cur?.symbol ?? "$";
  const formatted = (Math.round(amount * 100) / 100).toFixed(2);
  return `${symbol}${formatted.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
}

export function blankInvoice(): Invoice {
  const now = Date.now();
  const yr = new Date().getFullYear();
  const num = `INV-${yr}-${String(Math.floor(1000 + Math.random() * 9000))}`;
  return {
    id: crypto.randomUUID(),
    number: num,
    template: "modern",
    currency: "USD",
    issueDate: new Date().toISOString().slice(0, 10),
    dueDate: new Date(now + 14 * 86400000).toISOString().slice(0, 10),
    status: "draft",
    from: { name: "", email: "", address: "", phone: "" },
    to: { name: "", email: "", address: "", phone: "" },
    items: [
      { id: crypto.randomUUID(), description: "Service or product", quantity: 1, price: 100 },
    ],
    taxRate: 0,
    discount: 0,
    shipping: 0,
    notes: "Thank you for your business!",
    terms: "Payment due within 14 days.",
    createdAt: now,
    updatedAt: now,
  };
}
