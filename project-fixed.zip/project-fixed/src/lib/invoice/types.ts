export type TemplateId =
  | "minimal"
  | "corporate"
  | "modern"
  | "dark"
  | "luxury"
  | "creative";

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  price: number;
}

export interface Party {
  name: string;
  email: string;
  address: string;
  phone: string;
}

export interface Invoice {
  id: string;
  number: string;
  template: TemplateId;
  currency: string;
  logo?: string; // dataURL
  issueDate: string;
  dueDate: string;
  status: "draft" | "sent" | "paid";
  from: Party;
  to: Party;
  items: LineItem[];
  taxRate: number; // %
  discount: number; // flat amount
  shipping: number;
  notes: string;
  terms: string;
  createdAt: number;
  updatedAt: number;
}

export const CURRENCIES = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "CHF", symbol: "CHF", name: "Swiss Franc" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham" },
  { code: "SGD", symbol: "S$", name: "Singapore Dollar" },
];

export const TEMPLATES: { id: TemplateId; name: string; tagline: string; premium?: boolean }[] = [
  { id: "minimal", name: "Minimal", tagline: "Clean & timeless" },
  { id: "corporate", name: "Corporate", tagline: "Structured & formal" },
  { id: "modern", name: "Modern Gradient", tagline: "Bold & vibrant" },
  { id: "dark", name: "Dark Mode", tagline: "Sleek & premium", premium: true },
  { id: "luxury", name: "Luxury", tagline: "Elegant gold accents", premium: true },
  { id: "creative", name: "Creative", tagline: "For agencies & studios", premium: true },
];
