import type { TemplateId } from "@/lib/invoice/types";

const PREMIUM_KEY = "invoiceflow.premium.active.v1";

export const PREMIUM_TEMPLATES = new Set<TemplateId>(["dark", "luxury", "creative"]);

function safeLs(): Storage | null {
  if (typeof window === "undefined") return null;
  try { return window.localStorage; } catch { return null; }
}

export function isPremiumTemplate(template: TemplateId) {
  return PREMIUM_TEMPLATES.has(template);
}

export function isPremiumActive() {
  return safeLs()?.getItem(PREMIUM_KEY) === "true";
}

export function activatePremium() {
  safeLs()?.setItem(PREMIUM_KEY, "true");
}

export function unlockableTemplate(template: TemplateId) {
  return !isPremiumTemplate(template) || isPremiumActive();
}